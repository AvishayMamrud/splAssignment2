10/12/2020
Fixed small bug. Replaced && with || in the termination test.

-------

03/12/2020
Added a new sync test. (Tests sync between unregister/ broadcast sending/ sending events

-------

02/12/2020

Published tester.
